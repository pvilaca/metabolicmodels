the file Main.m contains all functions for reconstruction draft model
We assume the user has a RAVEN toolbox installed