Additional file 7 - mol files for each metabolite to estimate pKa of metabolites for pH 6, 7, and 8 using MarvinBeans software

These files are ".mol" files for each metabolite to estimate pKa of metabolites for pH 6, 7, and 8 from the specific functional groups and the molecular structures of metabolites using MarvinBeans software.

Yon can download the MarvinBeans software from ChemAxon website (http://www.chemaxon.com/download/).

You are free to download and intstall the MarvinBeans software on your desktop or for academic purposes.

MarvinBeans is a collection tool to draw, display, and characterize chemical structures, substructures, and reactions. MarvinBeans consists of some kinds of tools including MarvinSketch, MarvinSpace, MarvinView, and MolConverter.