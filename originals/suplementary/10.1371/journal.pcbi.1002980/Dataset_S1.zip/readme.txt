This file contains the iAL1006 genome-scale model of Penicillium chrysogenum.

iAL1006 v1.00.xml
	iAL1006 in SBML level 2 version 3 format
iAL1006 v1.00.xlsx 
	iAL1006 in Microsoft Excel format. Including additional annotation and biomass 	composition calculations
iAL1006 metabolic map v1.00.xml
	CellDesigner map of the model. To be used with drawMap to overlay data on the map
simulations.xls
	Metabolic tasks that were used for model validation. To be used with checkTasks